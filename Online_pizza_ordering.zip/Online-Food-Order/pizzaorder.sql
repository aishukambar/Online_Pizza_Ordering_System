-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2020 at 05:41 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pizzaorder`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `Name` varchar(250) NOT NULL,
  `Email` varchar(250) NOT NULL,
  `Mobile` varchar(250) NOT NULL,
  `Subject` varchar(250) NOT NULL,
  `Message` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Name`, `Email`, `Mobile`, `Subject`, `Message`) VALUES
('Aishwarya Kambar', 'aishu@g.com', '9586743215', 'delivery', 'fast delivery'),
('Ashvin V K', 'ashvin@g.com', '7854963251', 'Food Quality', 'Fresh, and hot'),
('nidha', 'nidha@gmail.com', '998696572', 'delivery', 'Not so fast. Expected it to be faster.\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `username` varchar(30) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`username`, `fullname`, `email`, `contact`, `address`, `password`) VALUES
('aishwarya', 'Aishwarya Kambar', 'aishu@g.com', '9586743215', 'Banshankari', '123456789'),
('ashvin', 'Ashvin V K', 'ashvin@g.com', '7854963251', 'Basweshwarnagar', '0000'),
('ayesha', 'Ayesha S', 'ayesha@h.com', '8457965321', 'Basweshwarnagar', '9876543210'),
('nidha', 'nidha', 'nidha@gmail.com', '998696572', 'Maharashtra', 'suhail');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `F_ID` int(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` int(30) NOT NULL,
  `description` varchar(200) NOT NULL,
  `images_path` varchar(200) NOT NULL,
  `options` varchar(10) NOT NULL DEFAULT 'ENABLE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`F_ID`, `name`, `price`, `description`, `images_path`, `options`) VALUES
(58, 'Farmhouse Pizza', 145, 'Cheesy pizza with red bell pepper, capsicum, mushroom and panner', 'images/item1.jpg', 'ENABLE'),
(59, 'Margherita', 175, 'A classic delight with 100% real mozzarella cheese', 'images/item5.png', 'ENABLE'),
(60, 'Peppy Paneer', 215, 'Flavorful trio of juicy paneer, crisp capsicum with spicy red paprika', 'images/item2.png', 'ENABLE'),
(61, 'Veg Extravaganza ', 235, 'Black olives, capsicum, onion, grilled mushroom, corn, tomato, jalapeno and extra cheese', 'images/item3.png', 'ENABLE'),
(62, 'Mexican Green Wave', 240, 'Mexican herbs sprinkled on onion, olives, capsicum and basil', 'images/item6.png', 'ENABLE'),
(63, 'Veggie Paradise', 225, 'The perfect five! Onion, capsicum, red bell pepper, broccoli and mushroom', 'images/item4.png', 'ENABLE'),
(65, 'Chicken Pepperoni', 285, 'a classic flavor of chicken pepperoni, topped with extra cheese', 'images/item7.jpg', 'ENABLE'),
(66, 'Chicken Golden Delight', 235, 'Barbeque chicken with a topping of golden corn loaded with extra cheese.', 'images/item9.png', 'ENABLE'),
(68, 'Chicken Fiesta', 225, 'Grilled Chicken Rashers, Peri-Peri Chicken, Onion, Capsicum', 'images/item10.png', 'ENABLE'),
(69, 'Chicken Dominator', 305, 'Double Pepper Barbecue Chicken, Peri-Peri Chicken, Chicken Tikka and Grilled Chicken Rashers', 'images/item12.png', 'ENABLE'),
(70, 'Pepper Barbecue Chicken', 185, 'Pepper Barbecue chicken for that extra zing', 'images/img8.jpg', 'ENABLE'),
(71, 'Non Veg Supreme', 320, 'Supreme combination of peri-peri chicken, onion, capsicum, tomato and red paprika', 'images/item11.png', 'ENABLE'),
(72, 'Cheese Garlic Bread', 100, 'Baked to perfection. Your perfect pizza partner!', 'images/item17.jpg', 'ENABLE'),
(73, 'Classic Stuffed Garlic Bread ', 145, 'Freshly baked garlic bread with cheese, juicy corn and tangy jalapeno', 'images/item18.jpg', 'ENABLE'),
(74, 'Creamy Veg Pasta ', 130, 'Cheesy white sauce pasta with capsicum, broccoli and red bellpepper', 'images/item20.jpg', 'ENABLE'),
(75, 'Tikka Masala Veg Pasta', 130, 'Red spicy dressing, onion, tomato, parsley sprinkles', 'images/item19.jpg', 'ENABLE'),
(76, 'Coco Cola(500 ml)', 60, 'Sparkling and refreshing beverage', 'images/item13.jpg', 'ENABLE'),
(77, 'Fanta(500 ml)', 60, 'delicious orange flavoured beverage', 'images/item14.jpg', 'ENABLE'),
(78, 'Green Tea', 75, 'Fresh Green tea', 'images/item15.jpg', 'ENABLE'),
(79, 'Coffee', 45, 'Freshly ground coffee', 'images/item16.jpg', 'ENABLE');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_ID` int(30) NOT NULL,
  `F_ID` int(30) NOT NULL,
  `foodname` varchar(30) NOT NULL,
  `price` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `order_date` date NOT NULL,
  `username` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_ID`, `F_ID`, `foodname`, `price`, `quantity`, `order_date`, `username`) VALUES
(69, 60, 'Peppy Paneer', 215, 1, '2020-12-21', 'nidha'),
(70, 73, 'Classic Stuffed Garlic Bread ', 145, 1, '2020-12-21', 'aishwarya'),
(71, 61, 'Veg Extravaganza ', 235, 1, '2020-12-21', 'ayesha'),
(72, 69, 'Chicken Dominator', 305, 1, '2020-12-21', 'nidha'),
(73, 76, 'Coco Cola(500 ml)', 60, 1, '2020-12-21', 'ashvin'),
(74, 59, 'Margherita', 175, 1, '2020-12-22', 'nidha'),
(75, 73, 'Classic Stuffed Garlic Bread ', 145, 2, '2020-12-22', 'ayesha');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`F_ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_ID`),
  ADD KEY `F_ID` (`F_ID`),
  ADD KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_ID` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`F_ID`) REFERENCES `food` (`F_ID`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`username`) REFERENCES `customer` (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
